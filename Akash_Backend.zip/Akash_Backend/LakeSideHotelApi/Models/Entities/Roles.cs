﻿using Microsoft.Identity.Client;

namespace LakeSideHotelApi.Models.Entities
{
    public class Roles
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
