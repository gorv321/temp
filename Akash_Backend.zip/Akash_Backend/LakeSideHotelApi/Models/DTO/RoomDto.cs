﻿namespace LakeSideHotelApi.Models.DTO
{
    public class RoomDto
    {
        public string RoomType { get; set; }
        public double RoomPrice { get; set; }
        public string? Photo { get; set; }
    }
}
