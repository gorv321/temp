﻿namespace LakeSideHotelApi.Repository
{
    public interface ITokenRepositary
    {

        string CreateJwtToken();

    }
}
